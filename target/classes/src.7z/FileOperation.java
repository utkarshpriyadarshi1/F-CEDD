import javafx.collections.ObservableList;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.compressors.CompressorInputStream;
import org.apache.commons.compress.compressors.CompressorOutputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;

class FileOperation {

    private static int BUFFER_SIZE;
    private FileInputStream fileInputStream;
    private FileOutputStream fileOutputStream;
    private BufferedOutputStream bufferedOutputStream;
    private ArchiveEntry archiveEntry;
    private ArchiveOutputStream archiveOutputStream;
    private ArchiveInputStream archiveInputStream;
    private CompressorInputStream compressorInputStream;
    private CompressorOutputStream compressorOutputStream;
    private ArrayList<LocalFile> globalFileList = new ArrayList<LocalFile>();
    private int i = 0;
    private int size;
    private ProgressStatus progressStatus;
    private int countTask = 1;

    FileOperation() {
        BUFFER_SIZE = 4 * 1024;
    }

    private void getAllFiles(File[] fileArray, String getDirectory) {
        for (File tempFile : fileArray) {
            if (tempFile.isDirectory()) {
                getAllFiles(tempFile.listFiles(), getDirectory + tempFile.getName() + File.separator);
            } else {
                globalFileList.add(i, new LocalFile(tempFile, getDirectory + tempFile.getName()));
                i++;
            }
        }
    }

    private void getAllArchiveEntry(ArchiveEntry archiveEntry, ArchiveInputStream archiveInputStream) {
        try {
            i = 0;
            while ((archiveEntry = archiveInputStream.getNextEntry()) != null) {
                if (!new File(archiveEntry.getName()).exists()) {
                    if (archiveEntry.isDirectory()) {
                        boolean createDirectory = new File(archiveEntry.getName()).mkdir();
                        if (!createDirectory) {
                            System.out.println("Failed to create dir : " + archiveEntry.getName());
                        }

                    } else {
                        boolean createFile = new File(archiveEntry.getName()).createNewFile();
                        if (!createFile)
                            System.out.println("Failed to create file : " + archiveEntry.getName());
                        else {
                            globalFileList.add(i, new LocalFile(new File(archiveEntry.toString()), archiveEntry.getName()));
                            i++;
                        }
                    }
                } else {
                    System.out.println("File/ Folder already exists");
                }
            }
        } catch (Exception e) {

        } finally {

        }
    }

    private void getRelativeFileName(ObservableList<File> listFile) {
        File[] newArray = new File[listFile.size()];
        int i = 0;
        for (File tempFile : listFile) {
            newArray[i] = tempFile;
            i++;
        }
        getAllFiles(newArray, "");
    }

    private String getExtension(String inputFile) {
        String extension;
        if (inputFile.endsWith(".7z"))
            extension = ".7z";
        else if (inputFile.endsWith(".tar"))
            extension = ".tar";
        else if (inputFile.endsWith(".tar.bz2"))
            extension = ".tar.bz2";
        else if (inputFile.endsWith(".tgz") || inputFile.endsWith("tar.gz"))
            extension = ".tar.gz";
        else if (inputFile.endsWith(".tar.xz"))
            extension = ".tar.xz";
        else extension = ".zip";
        return extension;
    }

    private void onlyDecompress(String inputPath, String inputFile, String extension, String outputPath) {
        try {

            switch (extension) {
                case ".7z":
                    System.out.println(inputPath + inputFile);
                    SevenZFile sevenZFile = new SevenZFile(new File(inputPath + File.separator + inputFile));
                    SevenZArchiveEntry sevenZArchiveEntry;

                    while ((sevenZArchiveEntry = sevenZFile.getNextEntry()) != null) {
                        if (sevenZArchiveEntry.isDirectory()) {
                            File f = new File(sevenZArchiveEntry.getName());
                            boolean created = f.mkdir();
                            if (!created) {
                                System.out.printf("Unable to create directory '%s', during extraction of archive contents.\n", f.getAbsolutePath());
                            }
                        } else {
                            fileOutputStream = new FileOutputStream(outputPath + File.separator + sevenZArchiveEntry.getName());
                            byte[] content = new byte[Math.toIntExact(sevenZArchiveEntry.getSize())];
                            i = 0;
                            while ((i = sevenZFile.read(content)) != -1) {
                                fileOutputStream.write(content, 0, i);
                            }
                        }
                    }
                    break;

                case ".bz2":
                    fileOutputStream = new FileOutputStream(outputPath + File.separator + inputFile.replace(extension, ""));
                    compressorInputStream = new BZip2CompressorInputStream(new BufferedInputStream(new FileInputStream(inputPath + inputFile)));
                    final byte[] buffer1 = new byte[BUFFER_SIZE];
                    i = 0;
                    while ((i = compressorInputStream.read(buffer1)) != -1) {
                        fileOutputStream.write(buffer1, 0, i);
                    }
                    fileOutputStream.close();
                    compressorInputStream.close();
                    break;

                case ".gz":
                    fileOutputStream = new FileOutputStream(outputPath + File.separator + inputFile.replace(extension, ""));
                    compressorInputStream = new GzipCompressorInputStream(new BufferedInputStream(new FileInputStream(inputPath + inputFile)));
                    final byte[] buffer = new byte[BUFFER_SIZE];
                    i = 0;
                    while ((i = compressorInputStream.read(buffer)) != -1) {
                        fileOutputStream.write(buffer, 0, i);
                    }
                    fileOutputStream.close();
                    compressorInputStream.close();
                    break;

                case ".tar":
                    System.out.println(".tar");

                    fileInputStream = new FileInputStream(inputPath + inputFile);
                    archiveInputStream = new TarArchiveInputStream(new BufferedInputStream(fileInputStream));
                    System.out.println("input Stream");
                    while ((archiveEntry = archiveInputStream.getNextEntry()) != null) {
                        byte[] tmp = new byte[4 * 1024];
                        String outputFile = archiveEntry.getName();
                        fileOutputStream = new FileOutputStream(outputPath + File.separator + outputFile);
                        int size = 0;
                        System.out.println("outputStream");
                        while ((size = archiveInputStream.read(tmp)) != -1) {
                            System.out.print("r ");
                            fileOutputStream.write(tmp, 0, size);
                            System.out.print("w ");
                        }
                        fileOutputStream.flush();
                        fileOutputStream.close();
                        System.out.println("\n output stream closed");
                    }
                    archiveInputStream.close();
                    break;

                case ".xz":
                    fileOutputStream = new FileOutputStream(outputPath + File.separator + inputFile.replace(extension, ""));
                    compressorInputStream = new XZCompressorInputStream(new BufferedInputStream(new FileInputStream(inputPath + File.separator + inputFile)));
                    final byte[] buffer2 = new byte[BUFFER_SIZE];
                    i = 0;
                    while ((i = compressorInputStream.read(buffer2)) != -1) {
                        fileOutputStream.write(buffer2, 0, i);
                    }
                    fileOutputStream.close();
                    compressorInputStream.close();
                    break;

                case ".zip":

                    fileInputStream = new FileInputStream(inputPath + inputFile);
                    archiveInputStream = new ZipArchiveInputStream(new BufferedInputStream(fileInputStream));

                    while ((archiveEntry = archiveInputStream.getNextEntry()) != null) {
                        byte[] tmp = new byte[4 * 1024];
                        String outputFile = archiveEntry.getName();
                        System.out.println(outputFile);

                        progressStatus.display(outputFile, countTask);
                        countTask++;

                        if (archiveEntry.isDirectory()) {
                            if (new File(outputPath + File.separator + outputFile).mkdirs()) {
                                System.out.println("created");
                            } else {
                                System.out.println(" not created");
                            }
                        } else {
                            fileOutputStream = new FileOutputStream(outputPath + File.separator + outputFile);
                            i = 0;
                            while ((i = archiveInputStream.read(tmp)) != -1) {
                                fileOutputStream.write(tmp, 0, i);
                            }
                            fileOutputStream.flush();
                            fileOutputStream.close();
                            System.out.println("\n output stream closed");
                        }
                    }
                    archiveInputStream.close();
                    break;
                default:
            }
        } catch (Exception e) {

        } finally {

        }
    }

    private void onlyCompress(String inputFile, String extension) {
        try {
            fileInputStream = new FileInputStream(inputFile);
            fileOutputStream = new FileOutputStream(inputFile + extension);

            switch (extension) {
                case ".bz2":
                    compressorOutputStream = new BZip2CompressorOutputStream(new BufferedOutputStream(fileOutputStream));
                    break;
                case ".gz":
                    compressorOutputStream = new GzipCompressorOutputStream(new BufferedOutputStream(fileOutputStream));
                    break;
                case ".xz":
                    compressorOutputStream = new XZCompressorOutputStream(new BufferedOutputStream(fileOutputStream));
                    break;
                default:
                    break;
            }

            final byte[] buffer = new byte[BUFFER_SIZE];
            int n = 0;
            while ((n = fileInputStream.read(buffer)) != -1) {
                compressorOutputStream.write(buffer, 0, n);
            }
            compressorOutputStream.close();
            fileInputStream.close();
        } catch (Exception e) {

        } finally {
            new File(inputFile).delete();
        }
    }

    private void onlyArchive(String extension, String outputPath, String outputFile) {
        try {
            //progressStatus = new ProgressStatus("Compressing", outputPath, outputPath, globalFileList.size());

            switch (extension) {
                case ".zip":

                    fileOutputStream = new FileOutputStream(outputPath + File.separator + outputFile + extension);
                    bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
                    archiveOutputStream = new ZipArchiveOutputStream(bufferedOutputStream);

                    for (LocalFile tempFile : globalFileList) {
                        //new ProgressStatus("Compressing", outputPath, outputPath,globalFileList.size()).update(tempFile.getFile().toString(), countTask);
                        //countTask++;

                        fileInputStream = new FileInputStream(tempFile.getFile());
                        archiveEntry = new ZipArchiveEntry(tempFile.getFile(), tempFile.getDirectory());
                        archiveOutputStream.putArchiveEntry(archiveEntry);
                        byte[] tmp = new byte[1024];
                        size = 0;
                        while ((size = fileInputStream.read(tmp)) != -1) {
                            archiveOutputStream.write(tmp, 0, size);
                        }
                        archiveOutputStream.flush();
                        fileInputStream.close();
                        archiveOutputStream.closeArchiveEntry();
                    }
                    archiveOutputStream.close();
                    break;

                case ".tar":
                    fileOutputStream = new FileOutputStream(outputPath + File.separator + outputFile + extension);
                    bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
                    archiveOutputStream = new TarArchiveOutputStream(bufferedOutputStream);
                    //int count = 0;
                    //int total = inputFileList.length;
                    for (LocalFile tempFile : globalFileList) {
                        fileInputStream = new FileInputStream(tempFile.getFile());
                        archiveEntry = new TarArchiveEntry(tempFile.getFile(), tempFile.getDirectory());
                        archiveOutputStream.putArchiveEntry(archiveEntry);
                        byte[] tmp = new byte[4096];
                        size = 0;
                        while ((size = fileInputStream.read(tmp)) != -1) {
                            archiveOutputStream.write(tmp, 0, size);
                        }
                        archiveOutputStream.flush();
                        fileInputStream.close();
                        archiveOutputStream.closeArchiveEntry();
                        //count++;
                        //p2.setProgress(count/total);
                    }
                    archiveOutputStream.close();
                    break;

                case ".7z":
                    SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File(outputPath + File.separator + outputFile + extension));
                    for (LocalFile tempFile : globalFileList) {
                        fileInputStream = new FileInputStream(tempFile.getFile());
                        archiveEntry = new SevenZArchiveEntry();
                        archiveEntry = sevenZOutputFile.createArchiveEntry(tempFile.getFile(), tempFile.getDirectory());
                        //Check createArchive paramters
                        sevenZOutputFile.putArchiveEntry(archiveEntry);
                        byte[] tmp = new byte[8192];
                        size = 0;
                        while ((size = fileInputStream.read(tmp)) != -1) {
                            System.out.println("read");
                            sevenZOutputFile.write(tmp, 0, size);
                            System.out.println("write");
                        }

                        fileInputStream.close();
                        System.out.println("bufferedStream Closed");
                        sevenZOutputFile.closeArchiveEntry();
                        System.out.println("Entry Created");
                    }
                    sevenZOutputFile.close();
                    System.out.println("File Close");
                    break;
                default:
            }
        } catch (Exception e) {

        } finally {

        }
    }

    void compress(ObservableList<File> listFile, String extension, String outputPath, String outputFileName) {
        getRelativeFileName(listFile);
        switch (extension) {
            case ".7z":
            case ".zip":
            case ".tar":
                onlyArchive(extension, outputPath, outputFileName);
                break;
            case ".tar.bz2":
            case ".tar.gz":
            case ".tar.xz":
                onlyArchive(extension.substring(0, 4), outputPath, outputFileName);
                onlyCompress(outputPath + File.separator + outputFileName + extension.substring(0, 4), extension.substring(4));
                break;
            default:
        }
    }

    void decompress(String inputFile, String outputPath) {
        String extension = getExtension(inputFile);
        String inputPath = new File(inputFile).getAbsolutePath();
        inputFile = new File(inputFile).getName();
        inputPath = inputPath.replace(inputFile, "");

        switch (extension) {
            case ".7z":
            case ".tar":
            case ".zip":
                onlyDecompress(inputPath, inputFile, extension, outputPath);
                break;
            case ".tar.gz":
            case ".tar.bz2":
            case ".tar.xz":
                onlyDecompress(inputPath, inputFile, extension.substring(4), outputPath);
                onlyDecompress(outputPath + File.separator, inputFile.substring(0, inputFile.lastIndexOf(".")), extension.substring(0, 4), outputPath);
                new File(outputPath + File.separator + inputFile.substring(0, inputFile.lastIndexOf("."))).delete();

                break;
            default:
        }
    }

    void encrypt(String inputFile, String password, String outputPath) {
        try {

            fileInputStream = new FileInputStream(inputFile);
            String outputFile = new File(inputFile).getName();
            fileOutputStream = new FileOutputStream(outputPath + File.separator + outputFile + ".aes");

            byte[] key = password.getBytes("UTF-8");
            MessageDigest sha = MessageDigest.getInstance("SHA-1");
            key = sha.digest(key);
            key = Arrays.copyOf(key, 16);
            SecretKey secret = new SecretKeySpec(key, "AES");
            System.out.println(secret.getEncoded());

            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secret);
            System.out.println("Error 5");

            //file encryption
            byte[] input = new byte[64];
            System.out.println("Error 1");
            int bytesRead;
            System.out.println("Error 2");

            while ((bytesRead = fileInputStream.read(input)) != -1) {
                byte[] output = cipher.update(input, 0, bytesRead);
                System.out.println("Error 3");
                if (output != null)
                    fileOutputStream.write(output);
            }
            System.out.println("Error 4");
            byte[] output = cipher.doFinal();
            System.out.println("Error 5");
            if (output != null)
                fileOutputStream.write(output);

            System.out.println("Error 6");
            System.out.println("File Encrypted.");

        } catch (Exception e) {

        } finally {
            try {
                fileInputStream.close();
                fileOutputStream.flush();
                fileOutputStream.close();
            } catch (Exception e) {

            }
        }
    }

    void decrypt(String inputFile, String password, String outputPath) {

        try {
            fileInputStream = new FileInputStream(inputFile);
            String outputFile = new File(inputFile).getName();
            outputFile = outputFile.substring(0, outputFile.lastIndexOf("."));
            System.out.println(outputFile);
            fileOutputStream = new FileOutputStream(outputPath + File.separator + outputFile);

            byte[] key = password.getBytes("UTF-8");
            MessageDigest sha = MessageDigest.getInstance("SHA-1");
            key = sha.digest(key);
            key = Arrays.copyOf(key, 16);
            SecretKey secret = new SecretKeySpec(key, "AES");
            System.out.println(secret.getEncoded());

            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");

            cipher.init(Cipher.DECRYPT_MODE, secret);
            System.out.println("Cipher inint");

            byte[] in = new byte[64];
            int read;
            while ((read = fileInputStream.read(in)) != -1) {
                byte[] output = cipher.update(in, 0, read);
                if (output != null)
                    fileOutputStream.write(output);
            }

            byte[] output = cipher.doFinal();
            if (output != null)
                fileOutputStream.write(output);

            System.out.println("File Decrypted.");
        } catch (Exception e) {

        } finally {
            try {
                fileInputStream.close();
                fileOutputStream.flush();
                fileOutputStream.close();
            } catch (Exception e) {

            }
        }
    }
}